import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import torch
from torchvision import transforms, models
from torch.utils.data import Dataset
import numpy as np
import cv2
import face_recognition
from torch import nn
import warnings
warnings.filterwarnings("ignore")

UPLOAD_FOLDER = 'Uploaded_Files'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__, template_folder="templates")
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

DEVICE = 'cpu'

# ================= MODEL =================
class Model(nn.Module):
    def __init__(self, num_classes, latent_dim=2048, lstm_layers=1, hidden_dim=2048):
        super(Model, self).__init__()

        base_model = models.resnext50_32x4d(pretrained=True)
        self.model = nn.Sequential(*list(base_model.children())[:-2])

        self.lstm = nn.LSTM(latent_dim, hidden_dim, lstm_layers, bias=False)

        self.dp = nn.Dropout(0.4)
        self.linear1 = nn.Linear(2048, num_classes)
        self.avgpool = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        b, t, c, h, w = x.shape

        x = x.view(b*t, c, h, w)
        fmap = self.model(x)
        x = self.avgpool(fmap)

        x = x.view(b, t, 2048)
        x_lstm, _ = self.lstm(x)

        return fmap, self.dp(self.linear1(x_lstm[:, -1, :]))

# ================= DATASET =================
class ValidationDataset(Dataset):
    def __init__(self, video_paths, seq_len=20, transform=None):
        self.video_paths = video_paths
        self.seq_len = seq_len
        self.transform = transform

    def __len__(self):
        return len(self.video_paths)

    def __getitem__(self, idx):
        video_path = self.video_paths[idx]
        frames = []

        for frame in self.extract_frames(video_path):
            if frame is None:
                continue

            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            try:
                faces = face_recognition.face_locations(frame)
            except:
                continue

            if len(faces) == 0:
                continue

            top, right, bottom, left = faces[0]
            frame = frame[top:bottom, left:right]

            frames.append(self.transform(frame))

            if len(frames) == self.seq_len:
                break

        if len(frames) == 0:
            cap = cv2.VideoCapture(video_path)
            success, frame = cap.read()
            if success:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frames.append(self.transform(frame))

        while len(frames) < self.seq_len:
            frames.append(frames[-1])

        frames = torch.stack(frames)
        return frames.unsqueeze(0)

    def extract_frames(self, path):
        cap = cv2.VideoCapture(path)
        while True:
            success, frame = cap.read()
            if not success:
                break
            yield frame

# ================= PREDICTION =================
def predict(model, frames):
    model.eval()
    with torch.no_grad():
        _, outputs = model(frames)
        probs = torch.softmax(outputs, dim=1)

        pred = torch.argmax(probs, dim=1).item()
        confidence = probs[0][pred].item() * 100

    return pred, confidence

# ================= MAIN =================
def detectFakeVideo(video_path):
    transform = transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize((112, 112)),
        transforms.ToTensor(),
        transforms.Normalize([0.485,0.456,0.406],
                             [0.229,0.224,0.225])
    ])

    dataset = ValidationDataset([video_path], transform=transform)

    model = Model(2).to(DEVICE)
    model.load_state_dict(torch.load('model/df_model.pt', map_location=DEVICE))
    model.eval()

    frames = dataset[0].to(DEVICE)

    return predict(model, frames)

# ================= ROUTES =================
@app.route('/')
def home():
    return render_template('index.html')

# ✅ NEW ABOUT ROUTE
@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/Detect', methods=['POST'])
def detect():
    video = request.files['video']
    filename = secure_filename(video.filename)

    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    video.save(path)

    try:
        pred, conf = detectFakeVideo(path)
        result = "FAKE" if pred == 1 else "REAL"
    except Exception as e:
        result = str(e)
        conf = 0

    os.remove(path)

    return render_template('index.html',
                           result=result,
                           confidence=round(conf,2))

if __name__ == '__main__':
    app.run(port=3000)